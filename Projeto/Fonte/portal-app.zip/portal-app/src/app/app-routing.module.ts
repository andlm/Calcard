import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PropostaComponent } from './proposta/proposta.component';
import { PropostaAddComponent } from './proposta/propostaAdd.component';


//const routes: Routes = [];

const routes: Routes = [
  { path: 'propostas', component: PropostaComponent },
  { path: 'propostaAdd', component: PropostaAddComponent }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
