import { Component, OnInit } from '@angular/core';
import { Proposta } from '../models/proposta.model';
import { PropostaService } from '../proposta/proposta.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-proposta',
  templateUrl: './proposta.component.html',
  styleUrls: ['./proposta.component.css']
})
export class PropostaComponent implements OnInit {

  propostas: Proposta[];

  constructor(private router: Router, private propostaService: PropostaService) {}

  ngOnInit() {
    this.propostaService.getPropostas()
      .subscribe( data => {
        this.propostas = data;
      });
  };

  excluirProposta(proposta: Proposta): void {
    this.propostaService.excluirProposta(proposta)
      .subscribe( data => {
        this.propostas = this.propostas.filter(u => u !== proposta);
      })
  };

}

