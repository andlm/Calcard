import { Component, OnInit } from '@angular/core';
import { Proposta } from '../models/proposta.model';
import { PropostaService } from './proposta.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: './propostaAdd.component.html'
})
export class PropostaAddComponent {

  proposta: Proposta = new Proposta();

  constructor(private router: Router, private propostaService: PropostaService) {}

  adicionarProposta(): void {
    this.propostaService.adicionarProposta(this.proposta)
        .subscribe( data => {
          alert("Proposta criado com sucesso.");
        });
  };
}

