import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Proposta } from '../models/proposta.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class PropostaService {

    constructor(private http:HttpClient) {}

    private propostaGetPesquisarUrl = 'http://localhost:8080/portalCalcardPropostaRestService/rest/proposta/pesquisarPropostas/0';

    private propostaGetExcluirUrl = 'http://localhost:8080/portalCalcardPropostaRestService/rest/proposta/excluirProposta/';

    private propostaPostAdicionarUrl = 'http://localhost:8080/portalCalcardPropostaRestService/rest/proposta/adicionarProposta';

    public getPropostas() 
    {
        return this.http.get<Proposta[]>(this.propostaGetPesquisarUrl);
    }

    public excluirProposta(proposta) 
    {
        return this.http.delete(this.propostaGetExcluirUrl + "/"+ proposta.id);
    }

    public adicionarProposta(proposta) {
        return this.http.post<Proposta>(this.propostaPostAdicionarUrl, proposta);
    }
}
