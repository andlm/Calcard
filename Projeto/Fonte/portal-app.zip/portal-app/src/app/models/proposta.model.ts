export class Proposta {

    id: number;
    data: Date;
    nome: string;
    cpf: string;
    idade: number;
    sexo: string;
    estadocivil: string;
    estado: string;
    dependentes: number;
    renda: string;
    resultadoanalise: string;
    limite: string;
  }