import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PropostaComponent } from './proposta/proposta.component';
import { PropostaAddComponent } from './proposta/propostaAdd.component';

import { PropostaService } from './proposta/proposta.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    PropostaComponent,
    PropostaAddComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [PropostaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
